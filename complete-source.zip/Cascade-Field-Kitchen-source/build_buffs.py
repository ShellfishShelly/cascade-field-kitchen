from lxml import html
import json,pathlib
P=pathlib.Path('/workspace/scratch/db7e46ca9846/cooking-source')
r=html.parse(str(P/'buffs.html'));out={}
for idx in [5,6,7,8,16]:
 for tr in r.xpath('//table')[idx].xpath('.//tr')[1:]:
  t=tr.xpath('./td')
  if len(t)<6:continue
  name=' '.join(t[1].text_content().split())
  # Plain mechanical effect, preserve list separators.
  effects='; '.join(x.strip() for x in t[4].itertext() if x.strip())
  out[name]={'description':effects,'categories':[],'source':'https://abioticfactor.wiki.gg/wiki/Buffs_and_Debuffs'}
tags={
'XP':['Brain Drain',"Fisherman's Snack",'Sedentary Lifestyle','Big Brain','Heightened Senses','Lightfooted','Living Off the Land','Quick Reflexes'],
'Combat':['Scintillating Skin','Gourd Skin','Gourd Body','Primal Power','Royal Presence','Royal Inspiration','Too Hot to Handle','Hearty Bite','Very Hearty Bite','Desire of the Flesh','Temptation of the Flesh'],
'Movement':['Fish Out of Water','Wahoo!','Mega-Ante','Gourd Body'],
'Healing':['Healthy-Ish Bite','Restoring Bite','Honey Sealed','Slice of Home','Medi-Shroom'],
'Stamina':['Energy Boost','Sugar High','Very Hearty Bite'],
'Temperature':['Brain Freeze',"Frigid Queen's Favor",'Toasty Tummy','Royal Flush','Royal Radiance','Royal Basking'],
'Stealth':['Shady Business','Carbun Copy',"Don't Pester Me"],
'Fishing':['Glowing Gleaner',"Fisherman's Snack"],
'Survival':['Souper Satisfied','Sweet Tooth','Rad Resistant','Bodacious'],
'Utility':['Fog Caller','Grainy Vision','Flesh Ritual'],
'Drawbacks':['Flesh Ritual','Death','Borborygmus','Stinky','Sick','Sugar High','Gourd Body','Desire of the Flesh','Temptation of the Flesh']}
for category,names in tags.items():
 for name in names:
  if name in out:out[name]['categories'].append(category)
# Clarify non-mechanical flavor and mixed effects.
out['Caffeinated']['description']='No separate mechanical effect is documented for this status.'
out['Caffeinated']['categories']=['Utility']
out['Gourd Body']['description']='Reduces incoming damage by 25%; reduces movement speed (the reference lists −10, without an explicit unit).'
out['Temptation of the Flesh']['description']='Reduces incoming damage by 5%, but attracts the Leyak more frequently.'
out['Desire of the Flesh']['description']='Reduces incoming damage by 15%, but attracts the Leyak more frequently.'
out['Healthy-Ish Bite']['description']='Rapid healing, up to 180 health over the effect.'
out['Restoring Bite']['description']='Rapid healing, up to 120 health over the effect.'
out['Souper Satisfied']['description']='Hunger and thirst drain 20% more slowly.'
out['Sugar High']['description']='Stamina drains 25% more slowly; fatigue drains 10% faster and continence drains 25% faster.'
out['Sweet Tooth']['description']='Snacks and soda restore 25% more hunger and thirst; sweets restore 50% more.'
out['Borborygmus']['description']='A second trigger while active causes sickness.'
out['Stinky']['description']='Makes enemies more alert to your presence.'
out['Sick']['description']='Vomiting drains hunger and thirst. Clears after two vomiting episodes.'
(P/'buffs.json').write_text(json.dumps(out,indent=2));print(len(out),'buff definitions')
