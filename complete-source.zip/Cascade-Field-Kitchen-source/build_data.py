from lxml import html
from pathlib import Path
import json,re,urllib.parse,hashlib,subprocess,concurrent.futures,shutil
B=Path('/workspace/scratch/db7e46ca9846/cooking-source');O=Path('/workspace/sites/cascade-kitchen/dist');w=html.parse(str(B/'wiki-cooking.html'));db=json.loads((B/'db-food-index.json').read_text());chef=json.loads((B/'db-chef-recipes.json').read_text());meta=json.loads((B/'food-meta.json').read_text())['items'];buffs=json.loads((B/'buffs.json').read_text())
def text(e):return ' '.join(e.text_content().split())
def norm(s):return re.sub(r'[^a-z0-9]','',s.lower())
def links(e):return list(dict.fromkeys(e.xpath('.//a[@title]/@title')))
def num(s):
 try:return float(s)
 except:return None
idx={norm(k):v for k,v in db.items()};wm={norm(k):v for k,v in meta.items()}
def dbitem(n):return idx.get(norm(n)) or idx.get(norm(re.sub(r'^(Cooked |Baked )','',n)))
def nutrition(n,fallback=None):
 m=wm.get(norm(n));d=dbitem(n)
 if m and 'consumableHungerFill' in m['stats']:return num(m['stats'].get('consumableHungerFill',0)),num(m['stats'].get('consumableThirstFill',0))
 if d:return d['hunger'],d['thirst']
 return fallback or (None,None)
# Canonical source-image map, DB first for bundled high resolution game icons.
images={};urls={}
for n,d in db.items():images[n]=d['iconUrl'];urls[n]=d['source']
for f in [B/'wiki-cooking.html',B/'food.html',*list((B/'food-pages').glob('*.html')),*B.glob('soup-*.html')]:
 try:r=html.parse(str(f))
 except:continue
 for a in r.xpath('//a[@title][img]'):
  n=a.get('title');src=a.xpath('./img/@src')[0]
  if src.startswith('/images/'):
   # Use actual srcset URL if provided.
   ss=a.xpath('./img/@srcset');src=ss[0].split(',')[-1].strip().split(' ')[0] if ss else src
   images.setdefault(n,'https://abioticfactor.wiki.gg'+src)
   urls.setdefault(n,'https://abioticfactor.wiki.gg'+a.get('href'))
recipes=[]
def add(n,method,ins,portions=1,portion=None,h=None,t=None,bs=None,notes='',source=None,time=None):
 p=portion or n;nu=nutrition(p,(h,t));rs={'id':norm(n)+'-'+norm(method),'name':n,'method':method,'ingredients':ins,'portions':int(portions),'portionName':p,'hunger':nu[0],'thirst':nu[1],'buffs':bs or [],'notes':notes,'source':source or 'https://abioticfactor.wiki.gg/wiki/Cooking','cookTime':time,'aliases':[]}
 recipes.append(rs);return rs
for ti,method in [(1,'Frying'),(6,'Baking'),(7,'Baking')]:
 for row in w.xpath('//table')[ti].xpath('.//tr')[1:]:
  c=row.xpath('./td');n=text(c[1]);multi=ti==7;portion=text(c[2]) if multi else n;bi=3 if multi else 2;h=num(text(c[bi+1]));t=num(text(c[bi+2]));p=int(text(c[6])) if multi else 1
  add(n,method,[{'name':text(c[0]),'count':1}],p,portion,h,t,links(c[bi]),time=text(c[-1]))
# Extras explicitly documented in source recipes / item pages.
for raw,cooked,portion,p in [('Raw Anniversary Cake','Anniversary Cake','Slice of Anniversary Cake',6),('Raw Stuffed Mushroom Tray','Roasted Stuffed Mushroom Tray','Roasted Stuffed Mushroom',6),('Raw Stuffed Peppers Tray','Roasted Stuffed Peppers Tray','Roasted Stuffed Pepper',6)]:
 add(cooked,'Baking',[{'name':raw,'count':1}],p,portion,source=next((x['source'] for x in chef if x['name']==raw),None))
add('Cooked Royal Pepper','Frying',[{'name':'Royal Pepper','count':1}],bs=['Royal Radiance'],source='https://abioticfactor.wiki.gg/wiki/Cooked_Royal_Pepper')
# Prepared dishes and raw preparation recipes.
alias={'Gooey Meat Steak':'Cooked Gooey Meat Steak','Gutfish Eel Filet':'Cooked Gutfish Eel Filet','Peccary Chop':'Cooked Peccary Chop','Radfish Filet':'Cooked Radfish Filet','Fried "Egg"':'Cooked Fried "Egg"'}
for row in chef:
 n=row['name'];ins=[]
 for ing in row['ingredients']:
  ing=ing.copy();ing['name']=alias.get(ing['name'],ing['name']);alts={'Any Tomato':['Tomato','Super Tomato'],'Any (Cooked) Pest':['Cooked Pest','Cooked Pest Rump'],'Any Standard (Raw) Fish Filet':['Raw Antefish Filet','Raw Portal Fish Filet','Raw Radfish Filet','Raw Moon Fish Filet','Raw Chordfish Filet','Raw Gutfish Eel Filet','Raw Inkfish Filet','Raw Darkwater Fish Filet']}.get(ing['name'])
  if alts:ing['name']=alts[0];ing['alternatives']=alts
  ins.append(ing)
 if n=='Mushy Crab Sushi Platter':ins[0]['alternatives']=['Gem Crab','Opal Crab']
 prep=n.startswith('Raw ') or n in ['Antepasta','Atypical Butter','Buttery Popcorn Kernels']
 p=row['yield'];portion=n
 if n.endswith(' Platter'):p=6;portion=n[:-8]
 if n in ['Colorful Maki Plate','Penumbra Maki Plate']:p=6;portion='Single '+n.replace(' Plate','')
 rec=add(n,'Preparation' if prep else 'Prepared',ins,p,portion,source=row['source'])
 if prep and (n.startswith('Raw ') or n=='Buttery Popcorn Kernels'):
  rec['hunger']=None;rec['thirst']=None;rec['notes']='Preparation ingredient. Nutrition is shown on the finished dish; do not treat raw-dish stats as a cooked serving.'
# Direct source references for buffs, including pages not in cooking overview.
br=html.parse(str(B/'buffs.html'));byfood={}
for ti in [6,7,8,16]:
 for row in br.xpath('//table')[ti].xpath('.//tr')[1:]:
  c=row.xpath('./td')
  if len(c)<6:continue
  name=text(c[1])
  for food in links(c[5]):byfood.setdefault(norm(food),[]).append(name)
for ti in [8]:
 for row in w.xpath('//table')[ti].xpath('.//tr')[1:]:
  c=row.xpath('./td');byfood.setdefault(norm(text(c[0])),[]).extend(links(c[2]))
# Soup recipes: base pot yield is bowl fills; two drinks per fill.
for ti in [2,3,4,5]:
 for row in w.xpath('//table')[ti].xpath('.//tr')[1:]:
  c=row.xpath('./td');n=text(c[0]);ins=[]
  if ti in [2,3,4]:
   for slot in c[1].xpath('.//div[contains(concat(" ",@class," ")," af-item-slot ")]'):
    a=slot.xpath('.//a[@title]');qty=slot.xpath('.//*[contains(@class,"af-item-slot__text")]')
    if a:ins.append({'name':a[0].get('title'),'count':num(text(qty[0])) if qty else 1})
  else:
   ns=links(c[1]);ins=[{'name':ns[0],'count':1,'alternatives':ns}] if ns else [{'name':'Invalid ingredient combination','count':1}]
  ins.insert(0,{'name':'Water','count':1000,'unit':'ml'})
  if ti==2:rec=add(n,'Soup',ins,int(text(c[5]))*2,n,num(text(c[3])),num(text(c[4])),links(c[2]),'One pot fills 4 soup bowls; each full bowl is 2 consumable servings. Totals use 8 servings. Base yield, before Serving Seconds.',time=text(c[6]));rec['bowlFills']=4
  elif ti==3:rec=add(n,'Pot meals',ins,4,text(c[2]),num(text(c[4])),num(text(c[5])),links(c[3]),'Produces 4 individual bowl items (not the refillable, two-serving Soup Bowl).',time=text(c[6]))
  elif ti==4:rec=add(n,'Pot utility',ins,int(text(c[3])),text(c[2]),notes='Non-food output. Nutrition does not apply.',time=text(c[4]));rec['hunger']=rec['thirst']=None
  else:
   note='Failed / harmful soup. Any ONE listed harmful ingredient can trigger this result; alternatives are not a combined recipe.'
   if n=='Bad Soup':note='Failure result for a mixture that does not match a valid recipe. Reference table lists 2 bowl fills (4 drinks); its item page lists 4 fills. Default follows the Cooking table—edit yield if your game differs.'
   rec=add(n,'Soup',ins,int(text(c[5]))*2,n,num(text(c[3])),num(text(c[4])),links(c[2]),note,time=text(c[6]));rec['bowlFills']=int(text(c[5]));rec['failure']=True
# Read exact stats from cached soup pages where available.
for f in [*B.glob('soup-*.html'),*list((B/'food-pages').glob('*.html'))]:
 try:r=html.parse(str(f));ib=r.xpath('//aside[contains(@class,"portable-infobox")]');ib=ib[0] if ib else None
 except:continue
 if ib is None:continue
 names=ib.xpath('.//*[@data-source="name"]');n=text(names[0]) if names else '';vals={}
 for key in ['consumableHungerFill','consumableThirstFill']:
  v=ib.xpath(f'.//*[@data-source="{key}"]//*[contains(@class,"pi-data-value")]');vals[key]=num(text(v[0])) if v else 0
 if ib.xpath('.//*[@data-source="consumableHungerFill" or @data-source="consumableThirstFill"]'):
  for rec in recipes:
   if norm(rec['portionName'])==norm(n) and rec['method'] not in ['Preparation','Pot utility']:rec['hunger']=vals['consumableHungerFill'];rec['thirst']=vals['consumableThirstFill']
add('Alien Cheese Wheel','Ripening',[{'name':'Ripening Alien Cheese Wheel','count':1}],6,'Anteverse Cheese',notes='Let a Ripening Alien Cheese Wheel finish ripening, then place it and take 6 pieces of cheese. No heat required.',source='https://abioticfactor.wiki.gg/wiki/Alien_Cheese_Wheel')
# Use explicit food-buff associations from wiki.
for rec in recipes:
 for n in [rec['name'],rec['portionName']]:
  rec['buffs']+=byfood.get(norm(n),[])
 rec['buffs']=list(dict.fromkeys(rec['buffs']))
 rec['aliases']=list(dict.fromkeys([re.sub(r'^(Cooked |Baked )','',rec['name']),rec['name'].replace('"',''),rec['portionName'].replace('"','')]))
 # Raw prep is not a consumed portion.
 if rec['method']=='Preparation':rec['buffs']=[]
 if rec['name']=='Roasted Stuffed Mushroom Tray':rec['buffs']=['Medi-Shroom']
 if rec['name']=='Roasted Stuffed Peppers Tray':rec['buffs']=['Royal Presence'];rec['notes']='Sources disagree: item infobox lists 10 hunger / 4 thirst; its Food Values table lists 30 / 5 at base quality. Database baseline is displayed; edit to match your game.'
# Add preparation conversions needed for the full ingredient chain.
add('Vial of Milk','Preparation',[{'name':'Milk Sac','count':1}],1,notes='Distill one Milk Sac at the Distillation Bench.',source='https://www.abioticdatabase.com/blog/abiotic-factor-distillation-guide/')
add('Melted Ice Cream','Preparation',[{'name':'Ice Cream','count':1}],1,notes='Allow Ice Cream to melt. This is a spoilage transformation, not a stove recipe.',source='https://abioticfactor.wiki.gg/wiki/Melted_Ice_Cream')
# No arithmetic for non-food intermediates.
for rec in recipes:
 if rec['method']=='Preparation':rec['hunger']=rec['thirst']=None
# Keep only definitions actually referenced.
used={b for r in recipes for b in r['buffs']}
for b in used:
 if b not in buffs:buffs[b]={'description':'Effect not documented in the retrieved reference. Edit this definition in Recipe data.','categories':['Utility']};print('MISSING BUFF',b)
buffs={b:buffs[b] for b in sorted(used)}
# Item icons, prefer database aliases, then wiki imagery, reuse chemistry assets.
chem=json.loads(Path('/workspace/sites/abiotic-chemistry/dist/data.json').read_text())['items'];items={};needed=set()
for r in recipes:
 needed.update([r['name'],r['portionName']])
 for ing in r['ingredients']:needed.add(ing['name']);needed.update(ing.get('alternatives',[]))
imageidx={norm(k):v for k,v in images.items()}
def makeitem(n):
 d=dbitem(n);u=d['iconUrl'] if d else imageidx.get(norm(n));ext='.webp' if u and '.webp' in u else '.png';fn=hashlib.sha1(n.encode()).hexdigest()[:14]+ext;p=O/'icons'/fn
 v={'icon':None,'source':d['source'] if d else urls.get(n)}
 if n in chem and n not in ['Water']:
  src=Path('/workspace/sites/abiotic-chemistry/dist')/chem[n]['icon'];fn=hashlib.sha1(n.encode()).hexdigest()[:14]+'.webp';shutil.copyfile(src,O/'icons'/fn);v['icon']='icons/'+fn;return n,v
 if u:
  if not p.exists():subprocess.run(['curl','-Ls','--fail','--max-time','20',u,'-o',str(p)],capture_output=True)
  if p.exists() and p.stat().st_size>100:v['icon']='icons/'+fn
  else:print('ICON MISSING',n,flush=True)
 else:print('NO ICON URL',n,flush=True)
 return n,v
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:items=dict(ex.map(makeitem,sorted(needed)))
d={'schemaVersion':1,'meta':{'title':'Cascade Field Kitchen','checked':'2026-10-27','version':'Wiki reference + 1.4 database baseline; not fully verified against 1.5','note':'Nutrition uses source base values, before cooking-quality bonuses. Update 1.5 changed food values; references may lag. Every recipe and buff is editable.'},'recipes':recipes,'buffs':buffs,'items':items}
(O/'data.json').write_text(json.dumps(d,indent=2));print('DONE',len(recipes),len(items),'unknown nutrition',[(r['name'],r['hunger'],r['thirst']) for r in recipes if r['hunger'] is None and r['method'] not in ['Preparation','Pot utility']])
