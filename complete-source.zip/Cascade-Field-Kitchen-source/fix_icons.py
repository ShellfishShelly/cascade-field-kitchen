from lxml import html
from pathlib import Path
from PIL import Image
import json,subprocess,hashlib,concurrent.futures
b=Path('/workspace/scratch/db7e46ca9846/cooking-source');p=Path('/workspace/sites/cascade-kitchen/dist');d=json.loads((p/'data.json').read_text());missing={k for k,v in d['items'].items() if not v['icon']};found={}
for f in b.glob('*.html'):
 try:t=html.parse(str(f))
 except:continue
 for im in t.xpath('//img'):
  n=im.getparent().get('title','')
  if n in missing:
   src=im.get('src','');parts=src.split('/')
   if src.startswith('/images/thumb/'):found[n]='https://abioticfactor.wiki.gg/images/'+parts[3]
def grab(pair):
 n,url=pair;fn='icons/'+hashlib.sha1(n.encode()).hexdigest()[:14]+'.png';dest=p/fn
 subprocess.run(['curl','-Ls','--fail','--max-time','15',url,'-o',str(dest)],capture_output=True)
 try:Image.open(dest).verify();return n,fn
 except:return n,None
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 for n,fn in ex.map(grab,found.items()):
  if fn:d['items'][n]['icon']=fn
for n,alias in [("Fisherman's Glue (Soup)",'Harmonious Rice'),('Glue (Soup)','Harmonious Rice'),('Solder (Soup)','Harmonious Rice'),('Pot of Xanterium Rice','Harmonious Rice')]:
 if not d['items'][n]['icon']:d['items'][n]['icon']=d['items'][alias]['icon']
(p/'data.json').write_text(json.dumps(d,indent=2));print('Missing:',[k for k,v in d['items'].items() if not v['icon']])
