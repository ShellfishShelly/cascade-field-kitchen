# Cascade Field Kitchen

Buildless Abiotic Factor cooking planner. Serve `dist/` over HTTP. Run `node verify.cjs` for data and calculation checks.

## Updating recipes

`dist/data.json` is the canonical bundled dataset, schemaVersion 1. The site supports full JSON import/export and per-recipe edits saved to localStorage. Exports carry recipes, metadata, item icon paths, buff definitions and ingredient alternatives. Browser edits override the bundle on that device until restored or replaced by an import.

Each recipe has a unique id, name, cooking method, ingredients (`name`, `count`, optional `unit` and `alternatives`), integer `portions`, `portionName`, per-portion `hunger` and `thirst`, buff names, notes and HTTPS source. Null nutrition means unavailable/not applicable. Negative nutrition drains that meter. `bowlFills` identifies soups: one fill contains two consumable servings. The planner rounds requested portions up to whole recipe batches.

Buff definitions have descriptions and category arrays. Categories are editorial planning labels. Item icons are bundled game assets attributed to Deep Field Games / Playstack; missing imagery uses a neutral placeholder.

## Reference limits

169 recipe/preparation entries assembled from the Abiotic Factor wiki cooking tables, individual food pages and Abiotic Database. Nutrition combines wiki references and the database's 1.4 baseline; it is not fully verified against 1.5. Recent patch differences and conflicting sources are called out in the interface. Quality and Serving Seconds bonuses are not applied. Failed soup outcomes are included; generic overcooking/burning is not modeled as a recipe for every food.

Source collection scripts record the assembly process and refer to scratch source caches from the research session; use the JSON editor for routine updates without those caches. Every individual recipe links to its source.
